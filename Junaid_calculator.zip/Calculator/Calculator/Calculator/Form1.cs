﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        double op1;
        double op2;
        string op;
        double m;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void buttonplus_Click(object sender, EventArgs e)
        {
            buttondot.Enabled = true;
            op1 = double.Parse(textBox1.Text);
            op = "+";
            textBox1.Text = "";
        }

        private void buttonminus_Click(object sender, EventArgs e)
        {
            buttondot.Enabled = true;
            op1 = double.Parse(textBox1.Text);
            op = "-";
            textBox1.Text = "";
        }

        private void buttonmul_Click(object sender, EventArgs e)
        {
            buttondot.Enabled = true;
            op1 = double.Parse(textBox1.Text);
            op = "*";
            textBox1.Text = "";
        }

        private void buttondiv_Click(object sender, EventArgs e)
        {
            buttondot.Enabled = true;
            op1 = double.Parse(textBox1.Text);
            op = "/";
            textBox1.Text = "";
        }

        private void buttonequal_Click(object sender, EventArgs e)
        {
            op2 = double.Parse(textBox1.Text);
            switch (op)
            {
                case "+":
                    textBox1.Text = Convert.ToString(op1 + op2);
                    break;
                case "-":
                    textBox1.Text = Convert.ToString(op1 - op2);
                    break;
                case "*":
                    textBox1.Text = Convert.ToString(op1 * op2);
                    break;
                case "/":
                    textBox1.Text = Convert.ToString(op1 / op2);
                    break;
            }
            m = double.Parse(textBox1.Text);
        }

        private void buttonc_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            buttondot.Enabled = true;
        }

        private void buttonsin_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Sin(double.Parse(textBox1.Text)).ToString();
        }

        private void buttoncos_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Cos(double.Parse(textBox1.Text)).ToString();
        }

        private void buttontan_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Tan(double.Parse(textBox1.Text)).ToString();
        }

        private void buttonsqrt_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Sqrt(double.Parse(textBox1.Text)).ToString();
        }

        private void buttonexp_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Exp(double.Parse(textBox1.Text)).ToString();
        }

        private void buttonlog_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.Log(double.Parse(textBox1.Text)).ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = (-double.Parse(textBox1.Text)).ToString();
        }

        private void buttondot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
            buttondot.Enabled = false;
        }

        private void buttonm_Click(object sender, EventArgs e)
        {
            textBox1.Text = m.ToString();
        }

    }
}
